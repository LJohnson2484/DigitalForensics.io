import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Search, Eye, Database, Users, TrendingUp } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-cyan-400" />
              <h1 className="text-xl font-bold text-white">DigitalForensics.io</h1>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-cyan-500 hover:bg-cyan-600 text-white"
            >
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl font-bold text-white mb-6">
            Comprehensive Digital Forensics
            <span className="block text-cyan-400">& OSINT Investigation Platform</span>
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            Automate online profile investigation and risk assessment using multiple OSINT tools. 
            Identify digital footprints, data breaches, and security exposures across the web.
          </p>
          <div className="flex justify-center space-x-4">
            <Button 
              size="lg"
              onClick={() => window.location.href = '/api/login'}
              className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-3"
            >
              Start Investigation
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-slate-600 text-slate-300 hover:bg-slate-800 px-8 py-3"
            >
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-slate-800/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Integrated OSINT Tools
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <Search className="h-12 w-12 text-cyan-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Maigret Analysis</h3>
                <p className="text-slate-300">
                  Search usernames across 3000+ social media platforms and websites to build comprehensive profiles.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <Shield className="h-12 w-12 text-orange-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">HaveIBeenPwned</h3>
                <p className="text-slate-300">
                  Check email addresses against known data breaches to identify compromised accounts.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <Users className="h-12 w-12 text-green-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Username Availability</h3>
                <p className="text-slate-300">
                  Verify username availability across multiple platforms to map digital presence.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <Database className="h-12 w-12 text-purple-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">SpiderFoot Integration</h3>
                <p className="text-slate-300">
                  Automated OSINT collection from 200+ data sources for comprehensive intelligence gathering.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <TrendingUp className="h-12 w-12 text-red-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Risk Assessment</h3>
                <p className="text-slate-300">
                  Intelligent scoring system to evaluate digital exposure and security risks.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-6">
                <Eye className="h-12 w-12 text-blue-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Investigation Reports</h3>
                <p className="text-slate-300">
                  Generate comprehensive reports with findings, correlations, and actionable recommendations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Start Your Investigation?
          </h2>
          <p className="text-xl text-slate-300 mb-8">
            Join security professionals using DigitalForensics.io for comprehensive OSINT investigations.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-8 py-3"
          >
            Begin Investigation
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 border-t border-slate-700 py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-400">
            © 2024 DigitalForensics.io - Professional OSINT Investigation Platform
          </p>
        </div>
      </footer>
    </div>
  );
}
