import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft, Download, RefreshCw } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import ResultsOverview from "@/components/investigation/ResultsOverview";
import MaigretResults from "@/components/investigation/MaigretResults";
import HibpResults from "@/components/investigation/HibpResults";
import NamechkResults from "@/components/investigation/NamechkResults";
import SpiderfootResults from "@/components/investigation/SpiderfootResults";

export default function Investigation() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();
  const [, params] = useRoute("/investigation/:id");
  const investigationId = params?.id;

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: investigationStatus, isLoading: statusLoading, refetch } = useQuery({
    queryKey: ["/api/investigations", investigationId, "status"],
    enabled: !!investigationId,
    refetchInterval: (data) => {
      // Refetch every 5 seconds if investigation is still running
      return data?.investigation?.status === 'running' ? 5000 : false;
    },
    retry: false,
  });

  if (isLoading || statusLoading || !investigationId) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-slate-300">Loading investigation...</p>
        </div>
      </div>
    );
  }

  const investigation = investigationStatus?.investigation;
  const results = investigationStatus?.results || [];
  const findings = investigationStatus?.findings || [];
  const summary = investigationStatus?.summary;

  if (!investigation) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <p className="text-slate-300 mb-4">Investigation not found</p>
          <Link href="/">
            <Button className="bg-cyan-500 hover:bg-cyan-600">
              Return to Dashboard
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleRefresh = () => {
    refetch();
  };

  const handleExport = () => {
    // Create downloadable report
    const reportData = {
      investigation,
      results,
      findings,
      summary,
      generatedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `investigation-${investigation.targetValue}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Report Exported",
      description: "Investigation report has been downloaded successfully.",
    });
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2 text-slate-300 hover:text-white">
                <ArrowLeft className="h-5 w-5" />
                <span>Back to Dashboard</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Shield className="h-8 w-8 text-cyan-400" />
                <h1 className="text-xl font-bold text-white">Investigation: {investigation.targetValue}</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRefresh}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleExport}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <div className="flex items-center space-x-2">
                {user?.profileImageUrl && (
                  <img 
                    src={user.profileImageUrl} 
                    alt="User profile" 
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="text-sm font-medium text-slate-300">
                  {user?.firstName || 'Security Analyst'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Investigation Overview */}
        <ResultsOverview 
          investigation={investigation}
          summary={summary}
        />

        {/* Tool Results */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Maigret Results */}
          <MaigretResults 
            result={results.find((r: any) => r.toolName === 'maigret')}
            findings={findings.filter((f: any) => f.type === 'social_media')}
          />

          {/* HaveIBeenPwned Results */}
          <HibpResults 
            result={results.find((r: any) => r.toolName === 'hibp')}
            findings={findings.filter((f: any) => f.type === 'breach')}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Namechk Results */}
          <NamechkResults 
            result={results.find((r: any) => r.toolName === 'namechk')}
            findings={findings.filter((f: any) => f.type === 'username_availability')}
          />

          {/* SpiderFoot Results */}
          <SpiderfootResults 
            result={results.find((r: any) => r.toolName === 'spiderfoot')}
            findings={findings.filter((f: any) => f.type === 'technical_data')}
          />

          {/* Investigation Summary */}
          <div className="bg-slate-800 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <Shield className="h-5 w-5 mr-2 text-cyan-400" />
              Investigation Summary
            </h3>
            
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-400">Target</p>
                <p className="text-white font-medium">{investigation.targetValue}</p>
              </div>
              
              <div>
                <p className="text-sm text-slate-400">Type</p>
                <p className="text-white font-medium capitalize">{investigation.targetType}</p>
              </div>
              
              <div>
                <p className="text-sm text-slate-400">Started</p>
                <p className="text-white font-medium">
                  {investigation.startedAt ? new Date(investigation.startedAt).toLocaleString() : 'Not started'}
                </p>
              </div>
              
              {investigation.completedAt && (
                <div>
                  <p className="text-sm text-slate-400">Completed</p>
                  <p className="text-white font-medium">
                    {new Date(investigation.completedAt).toLocaleString()}
                  </p>
                </div>
              )}
              
              <div>
                <p className="text-sm text-slate-400">Tools Used</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {(investigation.toolsEnabled as string[]).map((tool) => (
                    <span key={tool} className="px-2 py-1 bg-slate-700 text-slate-300 text-xs rounded">
                      {tool}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
