import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Users, AlertTriangle, Clock, Plus, Eye, FileText } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";
import InvestigationForm from "@/components/investigation/InvestigationForm";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: investigations, isLoading: investigationsLoading } = useQuery({
    queryKey: ["/api/investigations"],
    retry: false,
  });

  if (isLoading || investigationsLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-slate-300">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const recentInvestigations = investigations?.slice(0, 5) || [];
  const activeInvestigations = investigations?.filter((inv: any) => inv.status === 'running') || [];
  const completedInvestigations = investigations?.filter((inv: any) => inv.status === 'completed') || [];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Shield className="h-8 w-8 text-cyan-400" />
                <h1 className="text-xl font-bold text-white">DigitalForensics.io</h1>
              </div>
              <nav className="hidden md:flex space-x-6">
                <Link href="/" className="text-cyan-400 px-3 py-2 text-sm font-medium border-b-2 border-cyan-400">
                  Dashboard
                </Link>
                <a href="#" className="text-slate-300 hover:text-white px-3 py-2 text-sm font-medium">
                  Investigations
                </a>
                <a href="#" className="text-slate-300 hover:text-white px-3 py-2 text-sm font-medium">
                  Reports
                </a>
                <a href="#" className="text-slate-300 hover:text-white px-3 py-2 text-sm font-medium">
                  Tools
                </a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                {user?.profileImageUrl && (
                  <img 
                    src={user.profileImageUrl} 
                    alt="User profile" 
                    className="w-8 h-8 rounded-full object-cover"
                  />
                )}
                <span className="text-sm font-medium text-slate-300">
                  {user?.firstName || 'Security Analyst'}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
                className="text-slate-300 hover:text-white"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user?.firstName || 'Analyst'}
          </h2>
          <p className="text-slate-400">
            Monitor your OSINT investigations and manage digital forensics cases.
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-400">Total Investigations</p>
                  <p className="text-2xl font-bold text-white">{investigations?.length || 0}</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                  <FileText className="h-6 w-6 text-cyan-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-400">Active Scans</p>
                  <p className="text-2xl font-bold text-white">{activeInvestigations.length}</p>
                </div>
                <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center">
                  <Clock className="h-6 w-6 text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-400">Completed</p>
                  <p className="text-2xl font-bold text-white">{completedInvestigations.length}</p>
                </div>
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                  <Shield className="h-6 w-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-400">High Risk Cases</p>
                  <p className="text-2xl font-bold text-white">
                    {investigations?.filter((inv: any) => inv.riskLevel === 'high' || inv.riskLevel === 'critical').length || 0}
                  </p>
                </div>
                <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* New Investigation Form */}
          <div className="lg:col-span-2">
            <InvestigationForm />
          </div>

          {/* Recent Investigations */}
          <div>
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-cyan-400" />
                  Recent Investigations
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recentInvestigations.length > 0 ? (
                  <div className="space-y-4">
                    {recentInvestigations.map((investigation: any) => (
                      <div key={investigation.id} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-white">{investigation.targetValue}</p>
                          <p className="text-xs text-slate-400">
                            {investigation.targetType} • {new Date(investigation.createdAt).toLocaleDateString()}
                          </p>
                          <div className="flex items-center mt-1">
                            <span className={`px-2 py-1 text-xs rounded ${
                              investigation.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                              investigation.status === 'running' ? 'bg-orange-500/20 text-orange-400' :
                              investigation.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                              'bg-slate-500/20 text-slate-400'
                            }`}>
                              {investigation.status}
                            </span>
                            {investigation.riskLevel && (
                              <span className={`ml-2 px-2 py-1 text-xs rounded ${
                                investigation.riskLevel === 'critical' ? 'bg-red-500/20 text-red-400' :
                                investigation.riskLevel === 'high' ? 'bg-orange-500/20 text-orange-400' :
                                investigation.riskLevel === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                                'bg-green-500/20 text-green-400'
                              }`}>
                                {investigation.riskLevel} risk
                              </span>
                            )}
                          </div>
                        </div>
                        <Link href={`/investigation/${investigation.id}`}>
                          <Button variant="ghost" size="sm" className="text-cyan-400 hover:text-cyan-300">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-slate-500 mx-auto mb-4" />
                    <p className="text-slate-400 mb-4">No investigations yet</p>
                    <p className="text-sm text-slate-500">Start your first OSINT investigation to see results here.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Active Scans */}
            {activeInvestigations.length > 0 && (
              <Card className="bg-slate-800 border-slate-700 mt-6">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-orange-400" />
                    Active Scans
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {activeInvestigations.map((investigation: any) => (
                      <div key={investigation.id} className="bg-slate-700 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-white">{investigation.targetValue}</span>
                          <span className="text-xs text-slate-400">{investigation.progress || 0}%</span>
                        </div>
                        <div className="w-full bg-slate-600 rounded-full h-1.5">
                          <div 
                            className="bg-cyan-400 h-1.5 rounded-full transition-all duration-300" 
                            style={{ width: `${investigation.progress || 0}%` }}
                          ></div>
                        </div>
                        <div className="mt-2 text-xs text-slate-400">OSINT Analysis in progress...</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
