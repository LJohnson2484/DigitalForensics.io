import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, ExternalLink, CheckCircle, XCircle, Loader2, AlertTriangle } from "lucide-react";
import { useState } from "react";

interface HibpResultsProps {
  result: any;
  findings: any[];
}

export default function HibpResults({ result, findings }: HibpResultsProps) {
  const [showAll, setShowAll] = useState(false);

  const getStatusIcon = () => {
    switch (result?.status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case "running":
        return <Loader2 className="h-4 w-4 text-orange-400 animate-spin" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Loader2 className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusText = () => {
    switch (result?.status) {
      case "completed": return "COMPLETED";
      case "running": return "RUNNING";
      case "failed": return "FAILED";
      default: return "PENDING";
    }
  };

  const getStatusColor = () => {
    switch (result?.status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "running": return "bg-orange-500/20 text-orange-400";
      case "failed": return "bg-red-500/20 text-red-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "border-red-500 bg-red-500/10";
      case "high": return "border-orange-500 bg-orange-500/10";
      case "medium": return "border-yellow-500 bg-yellow-500/10";
      default: return "border-slate-500 bg-slate-500/10";
    }
  };

  const displayedFindings = showAll ? findings : findings.slice(0, 3);

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Shield className="h-5 w-5 mr-2 text-orange-400" />
            <span className="text-white">HaveIBeenPwned</span>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {result?.status === "running" && (
          <div className="text-center py-8">
            <Loader2 className="h-8 w-8 text-orange-400 animate-spin mx-auto mb-4" />
            <p className="text-slate-300">Checking data breaches...</p>
          </div>
        )}

        {result?.status === "failed" && (
          <div className="text-center py-8">
            <XCircle className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <p className="text-slate-300 mb-2">Breach check failed</p>
            {result.errorMessage && (
              <p className="text-sm text-slate-400">{result.errorMessage}</p>
            )}
          </div>
        )}

        {result?.status === "completed" && (
          <>
            {findings.length > 0 ? (
              <div className="space-y-4">
                {displayedFindings.map((finding, index) => (
                  <div key={index} className={`p-4 rounded-lg border-l-4 ${getSeverityColor(finding.severity)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-white capitalize">{finding.platform}</h4>
                      <div className="flex items-center space-x-2">
                        {finding.metadata?.breachDate && (
                          <span className="text-xs text-slate-400">
                            {new Date(finding.metadata.breachDate).toLocaleDateString()}
                          </span>
                        )}
                        <AlertTriangle className="h-4 w-4 text-orange-400" />
                      </div>
                    </div>
                    
                    <p className="text-xs text-slate-300 mb-3">{finding.description}</p>
                    
                    {finding.metadata?.dataClasses && (
                      <div className="flex flex-wrap gap-1">
                        {finding.metadata.dataClasses.slice(0, 4).map((dataClass: string, idx: number) => (
                          <span key={idx} className="px-2 py-1 bg-red-500/20 text-red-400 text-xs rounded">
                            {dataClass}
                          </span>
                        ))}
                        {finding.metadata.dataClasses.length > 4 && (
                          <span className="px-2 py-1 bg-slate-500/20 text-slate-400 text-xs rounded">
                            +{finding.metadata.dataClasses.length - 4} more
                          </span>
                        )}
                      </div>
                    )}

                    {finding.metadata?.pwnCount && (
                      <p className="text-xs text-slate-400 mt-2">
                        {finding.metadata.pwnCount.toLocaleString()} accounts affected
                      </p>
                    )}
                  </div>
                ))}

                {findings.length > 3 && (
                  <div className="text-center pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowAll(!showAll)}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      {showAll ? `Show Less` : `Show ${findings.length - 3} More Breaches`}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Shield className="h-8 w-8 text-green-400 mx-auto mb-4" />
                <p className="text-green-400 font-medium mb-2">No breaches found!</p>
                <p className="text-slate-400 text-sm">This email address was not found in any known data breaches.</p>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-slate-700">
              <p className="text-sm text-slate-400">
                {findings.length > 0 ? (
                  <>Found in <span className="text-red-400 font-medium">{findings.length}</span> data breaches</>
                ) : (
                  "No data breaches detected"
                )}
              </p>
            </div>
          </>
        )}

        {!result && (
          <div className="text-center py-8">
            <div className="animate-pulse">
              <div className="h-4 bg-slate-700 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
