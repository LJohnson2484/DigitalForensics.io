import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Database, CheckCircle, XCircle, Loader2, Clock, Globe, Mail, Phone, Shield } from "lucide-react";
import { useState } from "react";

interface SpiderfootResultsProps {
  result: any;
  findings: any[];
}

export default function SpiderfootResults({ result, findings }: SpiderfootResultsProps) {
  const [showAll, setShowAll] = useState(false);

  const getStatusIcon = () => {
    switch (result?.status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case "running":
        return <Loader2 className="h-4 w-4 text-orange-400 animate-spin" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Loader2 className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusText = () => {
    switch (result?.status) {
      case "completed": return "COMPLETED";
      case "running": return "RUNNING";
      case "failed": return "FAILED";
      default: return "PENDING";
    }
  };

  const getStatusColor = () => {
    switch (result?.status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "running": return "bg-orange-500/20 text-orange-400";
      case "failed": return "bg-red-500/20 text-red-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  const getTypeIcon = (type: string) => {
    if (type.includes('DNS')) return <Globe className="h-4 w-4" />;
    if (type.includes('EMAIL')) return <Mail className="h-4 w-4" />;
    if (type.includes('PHONE')) return <Phone className="h-4 w-4" />;
    if (type.includes('WHOIS')) return <Database className="h-4 w-4" />;
    return <Shield className="h-4 w-4" />;
  };

  const getTypeColor = (type: string) => {
    if (type.includes('DNS')) return "text-blue-400";
    if (type.includes('EMAIL')) return "text-green-400";
    if (type.includes('PHONE')) return "text-purple-400";
    if (type.includes('WHOIS')) return "text-orange-400";
    return "text-slate-400";
  };

  const displayedFindings = showAll ? findings : findings.slice(0, 4);

  // Mock progress for running state
  const mockProgress = result?.status === "running" ? 45 : 100;
  const mockModules = [
    { name: "DNS Records", status: "completed", icon: Globe },
    { name: "WHOIS Data", status: "completed", icon: Database },
    { name: "Threat Intel", status: result?.status === "running" ? "running" : "completed", icon: Shield },
    { name: "Social Media", status: result?.status === "running" ? "pending" : "completed", icon: Mail },
  ];

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Database className="h-5 w-5 mr-2 text-slate-400" />
            <span className="text-white">SpiderFoot</span>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {result?.status === "running" && (
          <div className="space-y-4">
            <div className="space-y-3">
              {mockModules.map((module, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-2">
                    <module.icon className="h-4 w-4 text-slate-400" />
                    <span className="text-slate-400">{module.name}</span>
                  </div>
                  <span className={
                    module.status === "completed" ? "text-green-400" :
                    module.status === "running" ? "text-orange-400" :
                    "text-slate-500"
                  }>
                    {module.status === "completed" && <CheckCircle className="h-4 w-4" />}
                    {module.status === "running" && <Loader2 className="h-4 w-4 animate-spin" />}
                    {module.status === "pending" && <Clock className="h-4 w-4" />}
                  </span>
                </div>
              ))}
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-400">Progress</span>
                <span className="text-white font-medium">{mockProgress}%</span>
              </div>
              <Progress value={mockProgress} className="h-2" />
              <p className="text-xs text-slate-400 mt-2">{mockProgress}% complete - ETA: 5 minutes</p>
            </div>
          </div>
        )}

        {result?.status === "failed" && (
          <div className="text-center py-8">
            <XCircle className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <p className="text-slate-300 mb-2">SpiderFoot analysis failed</p>
            {result.errorMessage && (
              <p className="text-sm text-slate-400">{result.errorMessage}</p>
            )}
          </div>
        )}

        {result?.status === "completed" && (
          <>
            {findings.length > 0 ? (
              <div className="space-y-3">
                {displayedFindings.map((finding, index) => (
                  <div key={index} className="p-3 bg-slate-700 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <div className={getTypeColor(finding.metadata?.spiderfoot_type || '')}>
                          {getTypeIcon(finding.metadata?.spiderfoot_type || '')}
                        </div>
                        <span className="text-sm font-medium text-white">
                          {finding.metadata?.spiderfoot_type?.replace('_', ' ') || 'Technical Data'}
                        </span>
                      </div>
                      <span className={`px-2 py-1 text-xs rounded ${
                        finding.severity === 'high' ? 'bg-orange-500/20 text-orange-400' :
                        finding.severity === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>
                        {finding.severity}
                      </span>
                    </div>
                    
                    <p className="text-xs text-slate-300 mb-2">{finding.description}</p>
                    
                    {finding.metadata?.data && (
                      <div className="text-xs font-mono text-cyan-400 bg-slate-800 p-2 rounded">
                        {typeof finding.metadata.data === 'string' 
                          ? finding.metadata.data 
                          : JSON.stringify(finding.metadata.data, null, 2).slice(0, 100) + '...'}
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-2 text-xs text-slate-400">
                      <span>Confidence: {finding.confidence}%</span>
                      {finding.metadata?.source && (
                        <span>Source: {finding.metadata.source}</span>
                      )}
                    </div>
                  </div>
                ))}

                {findings.length > 4 && (
                  <div className="text-center pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowAll(!showAll)}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      {showAll ? `Show Less` : `Show ${findings.length - 4} More`}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Database className="h-8 w-8 text-slate-500 mx-auto mb-4" />
                <p className="text-slate-400">No technical data found</p>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-slate-700">
              <p className="text-sm text-slate-400">
                Collected <span className="text-white font-medium">{findings.length}</span> technical data points
              </p>
            </div>
          </>
        )}

        {!result && (
          <div className="text-center py-8">
            <div className="animate-pulse">
              <div className="h-4 bg-slate-700 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
