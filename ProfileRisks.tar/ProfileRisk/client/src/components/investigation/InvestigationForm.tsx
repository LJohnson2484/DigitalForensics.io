import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Search, Play, Loader2 } from "lucide-react";
import { useLocation } from "wouter";

const investigationSchema = z.object({
  name: z.string().min(1, "Investigation name is required"),
  targetType: z.enum(["username", "email", "phone", "domain"]),
  targetValue: z.string().min(1, "Target value is required"),
  toolsEnabled: z.array(z.string()).min(1, "Select at least one tool"),
});

type InvestigationFormData = z.infer<typeof investigationSchema>;

const toolOptions = [
  { id: "maigret", label: "Maigret", description: "Username analysis across 3000+ platforms" },
  { id: "hibp", label: "HaveIBeenPwned", description: "Data breach detection" },
  { id: "namechk", label: "Namechk", description: "Username availability checker" },
  { id: "spiderfoot", label: "SpiderFoot", description: "Automated OSINT collection" },
];

export default function InvestigationForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();

  const form = useForm<InvestigationFormData>({
    resolver: zodResolver(investigationSchema),
    defaultValues: {
      name: "",
      targetType: "username",
      targetValue: "",
      toolsEnabled: ["maigret", "hibp", "namechk"],
    },
  });

  const createInvestigationMutation = useMutation({
    mutationFn: async (data: InvestigationFormData) => {
      const response = await apiRequest("POST", "/api/investigations", data);
      return response.json();
    },
    onSuccess: (investigation) => {
      toast({
        title: "Investigation Started",
        description: `Investigation "${investigation.name}" has been created and is now running.`,
      });
      queryClient.invalidateQueryKey(["/api/investigations"]);
      form.reset();
      setLocation(`/investigation/${investigation.id}`);
    },
    onError: (error) => {
      console.error("Investigation creation failed:", error);
      toast({
        title: "Failed to Start Investigation",
        description: "Please check your input and try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InvestigationFormData) => {
    createInvestigationMutation.mutate(data);
  };

  const targetType = form.watch("targetType");

  const getPlaceholder = () => {
    switch (targetType) {
      case "username": return "johndoe123";
      case "email": return "john.doe@example.com";
      case "phone": return "+1-555-123-4567";
      case "domain": return "example.com";
      default: return "";
    }
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Search className="h-5 w-5 mr-2 text-cyan-400" />
          New OSINT Investigation
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Investigation Name</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="My OSINT Investigation"
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-cyan-400 focus:ring-cyan-400"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="targetType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-300">Target Type</FormLabel>
                    <FormControl>
                      <select
                        {...field}
                        className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                      >
                        <option value="username">Username</option>
                        <option value="email">Email Address</option>
                        <option value="phone">Phone Number</option>
                        <option value="domain">Domain</option>
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="targetValue"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-slate-300">Target Value</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder={getPlaceholder()}
                        className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-cyan-400 focus:ring-cyan-400"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="toolsEnabled"
              render={() => (
                <FormItem>
                  <FormLabel className="text-slate-300">Investigation Tools</FormLabel>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {toolOptions.map((tool) => (
                      <FormField
                        key={tool.id}
                        control={form.control}
                        name="toolsEnabled"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={tool.id}
                              className="flex flex-row items-start space-x-3 space-y-0 p-3 border border-slate-600 rounded-lg"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(tool.id)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, tool.id])
                                      : field.onChange(
                                          field.value?.filter(
                                            (value) => value !== tool.id
                                          )
                                        );
                                  }}
                                  className="border-slate-500 data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-500"
                                />
                              </FormControl>
                              <div className="space-y-1 leading-none">
                                <FormLabel className="text-sm font-medium text-white">
                                  {tool.label}
                                </FormLabel>
                                <p className="text-xs text-slate-400">
                                  {tool.description}
                                </p>
                              </div>
                            </FormItem>
                          );
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => form.reset()}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Clear
              </Button>
              <Button
                type="submit"
                disabled={createInvestigationMutation.isPending}
                className="bg-cyan-500 hover:bg-cyan-600 text-white"
              >
                {createInvestigationMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Starting...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 mr-2" />
                    Start Investigation
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
