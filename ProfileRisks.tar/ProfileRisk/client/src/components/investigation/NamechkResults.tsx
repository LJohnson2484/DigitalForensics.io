import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserCheck, ExternalLink, CheckCircle, XCircle, Loader2, Users } from "lucide-react";
import { useState } from "react";

interface NamechkResultsProps {
  result: any;
  findings: any[];
}

export default function NamechkResults({ result, findings }: NamechkResultsProps) {
  const [showDetails, setShowDetails] = useState(false);

  const getStatusIcon = () => {
    switch (result?.status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case "running":
        return <Loader2 className="h-4 w-4 text-orange-400 animate-spin" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Loader2 className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusText = () => {
    switch (result?.status) {
      case "completed": return "COMPLETED";
      case "running": return "RUNNING";
      case "failed": return "FAILED";
      default: return "PENDING";
    }
  };

  const getStatusColor = () => {
    switch (result?.status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "running": return "bg-orange-500/20 text-orange-400";
      case "failed": return "bg-red-500/20 text-red-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  const getPlatformIcon = (platform: string) => {
    const iconMap: Record<string, string> = {
      twitter: "fab fa-twitter",
      github: "fab fa-github",
      instagram: "fab fa-instagram",
      linkedin: "fab fa-linkedin",
      facebook: "fab fa-facebook",
      reddit: "fab fa-reddit",
      youtube: "fab fa-youtube",
      tiktok: "fab fa-tiktok",
    };
    
    return iconMap[platform.toLowerCase()] || "fas fa-globe";
  };

  const getPlatformColor = (platform: string) => {
    const colorMap: Record<string, string> = {
      twitter: "#1DA1F2",
      github: "#333",
      instagram: "#E4405F",
      linkedin: "#0077B5",
      facebook: "#1877F2",
      reddit: "#FF4500",
      youtube: "#FF0000",
      tiktok: "#000000",
    };
    
    return colorMap[platform.toLowerCase()] || "#64748b";
  };

  const platformData = result?.results || {};
  const { available = 0, taken = 0, unknown = 0, platforms = [] } = platformData;

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <UserCheck className="h-5 w-5 mr-2 text-green-400" />
            <span className="text-white">Namechk</span>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {result?.status === "running" && (
          <div className="text-center py-8">
            <Loader2 className="h-8 w-8 text-green-400 animate-spin mx-auto mb-4" />
            <p className="text-slate-300">Checking username availability...</p>
          </div>
        )}

        {result?.status === "failed" && (
          <div className="text-center py-8">
            <XCircle className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <p className="text-slate-300 mb-2">Username check failed</p>
            {result.errorMessage && (
              <p className="text-sm text-slate-400">{result.errorMessage}</p>
            )}
          </div>
        )}

        {result?.status === "completed" && (
          <>
            <div className="space-y-3 mb-6">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Available</span>
                <span className="text-green-400 font-medium">{available}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Taken</span>
                <span className="text-red-400 font-medium">{taken}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-400">Unknown</span>
                <span className="text-slate-400 font-medium">{unknown}</span>
              </div>
            </div>

            {platforms.length > 0 && (
              <>
                <div className="mb-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowDetails(!showDetails)}
                    className="border-slate-600 text-slate-300 hover:bg-slate-700 w-full"
                  >
                    {showDetails ? "Hide Platform Details" : "View Platform Details"}
                  </Button>
                </div>

                {showDetails && (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {platforms.map((platform: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-slate-700 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <i 
                            className={`${getPlatformIcon(platform.name)} text-sm`}
                            style={{ color: getPlatformColor(platform.name) }}
                          ></i>
                          <span className="text-sm text-white">{platform.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 text-xs rounded ${
                            platform.status === 'taken' ? 'bg-red-500/20 text-red-400' :
                            platform.status === 'available' ? 'bg-green-500/20 text-green-400' :
                            'bg-slate-500/20 text-slate-400'
                          }`}>
                            {platform.status.toUpperCase()}
                          </span>
                          {platform.url && platform.status === 'taken' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(platform.url, '_blank')}
                              className="text-cyan-400 hover:text-cyan-300 p-1"
                            >
                              <ExternalLink className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            <div className="mt-4 pt-4 border-t border-slate-700">
              <p className="text-sm text-slate-400">
                Checked availability across {platforms.length} platforms
              </p>
            </div>
          </>
        )}

        {!result && (
          <div className="text-center py-8">
            <div className="animate-pulse">
              <div className="h-4 bg-slate-700 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
