import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Users, Shield, TrendingUp, Clock } from "lucide-react";

interface ResultsOverviewProps {
  investigation: any;
  summary: any;
}

export default function ResultsOverview({ investigation, summary }: ResultsOverviewProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case "critical": return "text-red-400";
      case "high": return "text-orange-400";
      case "medium": return "text-yellow-400";
      case "low": return "text-green-400";
      default: return "text-slate-400";
    }
  };

  const getRiskBgColor = (level: string) => {
    switch (level) {
      case "critical": return "bg-red-500/20";
      case "high": return "bg-orange-500/20";
      case "medium": return "bg-yellow-500/20";
      case "low": return "bg-green-500/20";
      default: return "bg-slate-500/20";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "running": return "bg-orange-500/20 text-orange-400";
      case "failed": return "bg-red-500/20 text-red-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  return (
    <div className="mb-8">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-white">Investigation Results</h2>
          <span className={`px-3 py-1 text-xs font-medium rounded-full uppercase ${getStatusColor(investigation.status)}`}>
            {investigation.status}
          </span>
        </div>
        
        {investigation.status === 'running' && (
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-400">Progress</span>
              <span className="text-white font-medium">{investigation.progress || 0}%</span>
            </div>
            <Progress value={investigation.progress || 0} className="h-2" />
          </div>
        )}
      </div>

      {/* Risk Assessment Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-400">Overall Risk</p>
                <p className={`text-2xl font-bold ${getRiskColor(investigation.riskLevel || 'unknown')}`}>
                  {investigation.riskLevel ? investigation.riskLevel.toUpperCase() : 'ANALYZING'}
                </p>
              </div>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center ${getRiskBgColor(investigation.riskLevel || 'unknown')}`}>
                <AlertTriangle className={`text-xl ${getRiskColor(investigation.riskLevel || 'unknown')}`} />
              </div>
            </div>
            {investigation.riskScore && (
              <div className="mt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Risk Score</span>
                  <span className="text-white font-medium">{investigation.riskScore}/100</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2 mt-2">
                  <div 
                    className={`h-2 rounded-full ${
                      investigation.riskScore >= 80 ? 'bg-gradient-to-r from-red-500 to-red-400' :
                      investigation.riskScore >= 60 ? 'bg-gradient-to-r from-orange-500 to-orange-400' :
                      investigation.riskScore >= 30 ? 'bg-gradient-to-r from-yellow-500 to-yellow-400' :
                      'bg-gradient-to-r from-green-500 to-green-400'
                    }`}
                    style={{ width: `${investigation.riskScore}%` }}
                  ></div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-400">Total Findings</p>
                <p className="text-2xl font-bold text-white">{summary?.totalFindings || 0}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-cyan-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-400">High Priority</p>
                <p className="text-2xl font-bold text-orange-400">{summary?.highSeverityFindings || 0}</p>
              </div>
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center">
                <Shield className="h-6 w-6 text-orange-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-400">Tools Progress</p>
                <p className="text-2xl font-bold text-green-400">
                  {summary?.completedTools || 0}/{summary?.totalTools || 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
