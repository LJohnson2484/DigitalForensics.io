import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, ExternalLink, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useState } from "react";

interface MaigretResultsProps {
  result: any;
  findings: any[];
}

export default function MaigretResults({ result, findings }: MaigretResultsProps) {
  const [showAll, setShowAll] = useState(false);

  const getStatusIcon = () => {
    switch (result?.status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case "running":
        return <Loader2 className="h-4 w-4 text-orange-400 animate-spin" />;
      case "failed":
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return <Loader2 className="h-4 w-4 text-slate-400" />;
    }
  };

  const getStatusText = () => {
    switch (result?.status) {
      case "completed": return "COMPLETED";
      case "running": return "RUNNING";
      case "failed": return "FAILED";
      default: return "PENDING";
    }
  };

  const getStatusColor = () => {
    switch (result?.status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "running": return "bg-orange-500/20 text-orange-400";
      case "failed": return "bg-red-500/20 text-red-400";
      default: return "bg-slate-500/20 text-slate-400";
    }
  };

  const displayedFindings = showAll ? findings : findings.slice(0, 5);

  const getPlatformIcon = (platform: string) => {
    const iconMap: Record<string, string> = {
      twitter: "fab fa-twitter",
      github: "fab fa-github",
      instagram: "fab fa-instagram",
      linkedin: "fab fa-linkedin",
      facebook: "fab fa-facebook",
      reddit: "fab fa-reddit",
      youtube: "fab fa-youtube",
      tiktok: "fab fa-tiktok",
    };
    
    return iconMap[platform.toLowerCase()] || "fas fa-globe";
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Search className="h-5 w-5 mr-2 text-cyan-400" />
            <span className="text-white">Maigret Analysis</span>
          </div>
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor()}`}>
              {getStatusText()}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {result?.status === "running" && (
          <div className="text-center py-8">
            <Loader2 className="h-8 w-8 text-cyan-400 animate-spin mx-auto mb-4" />
            <p className="text-slate-300">Searching across 3000+ platforms...</p>
          </div>
        )}

        {result?.status === "failed" && (
          <div className="text-center py-8">
            <XCircle className="h-8 w-8 text-red-400 mx-auto mb-4" />
            <p className="text-slate-300 mb-2">Maigret analysis failed</p>
            {result.errorMessage && (
              <p className="text-sm text-slate-400">{result.errorMessage}</p>
            )}
          </div>
        )}

        {result?.status === "completed" && (
          <>
            {findings.length > 0 ? (
              <div className="space-y-3">
                {displayedFindings.map((finding, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <i className={`${getPlatformIcon(finding.platform)} text-lg`} style={{
                        color: finding.platform === 'twitter' ? '#1DA1F2' :
                               finding.platform === 'github' ? '#333' :
                               finding.platform === 'instagram' ? '#E4405F' :
                               finding.platform === 'linkedin' ? '#0077B5' :
                               finding.platform === 'facebook' ? '#1877F2' :
                               finding.platform === 'reddit' ? '#FF4500' :
                               finding.platform === 'youtube' ? '#FF0000' :
                               finding.platform === 'tiktok' ? '#000000' :
                               '#64748b'
                      }}></i>
                      <div>
                        <p className="text-sm font-medium text-white capitalize">{finding.platform}</p>
                        <p className="text-xs text-slate-400">{finding.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                        FOUND
                      </span>
                      {finding.url && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(finding.url, '_blank')}
                          className="text-cyan-400 hover:text-cyan-300 p-1"
                        >
                          <ExternalLink className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}

                {findings.length > 5 && (
                  <div className="text-center pt-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowAll(!showAll)}
                      className="border-slate-600 text-slate-300 hover:bg-slate-700"
                    >
                      {showAll ? `Show Less` : `Show ${findings.length - 5} More`}
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Search className="h-8 w-8 text-slate-500 mx-auto mb-4" />
                <p className="text-slate-400">No accounts found across searched platforms</p>
              </div>
            )}

            <div className="mt-4 pt-4 border-t border-slate-700">
              <p className="text-sm text-slate-400">
                Found <span className="text-white font-medium">{findings.length}</span> accounts across social media platforms
              </p>
            </div>
          </>
        )}

        {!result && (
          <div className="text-center py-8">
            <div className="animate-pulse">
              <div className="h-4 bg-slate-700 rounded w-3/4 mx-auto mb-2"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
