import { storage } from "../storage";
import { spawn } from "child_process";
import { promises as fs } from "fs";
import path from "path";
import os from "os";

class SpiderFootService {
  async run(target: string, investigationId: string): Promise<void> {
    console.log(`Running SpiderFoot for target: ${target}`);
    
    // Update result status to running
    const results = await storage.getInvestigationResults(investigationId);
    const spiderfootResult = results.find(r => r.toolName === 'spiderfoot');
    if (spiderfootResult) {
      await storage.updateInvestigationResult(spiderfootResult.id, {
        status: "running",
        startedAt: new Date(),
      });
    }

    try {
      // Check if SpiderFoot is available, otherwise use mock data
      const spiderfootResults = await this.runSpiderFootCommand(target);
      await this.processResults(spiderfootResults, investigationId, spiderfootResult?.id);
      
    } catch (error) {
      console.error("SpiderFoot service error:", error);
      if (spiderfootResult) {
        await storage.updateInvestigationResult(spiderfootResult.id, {
          status: "failed",
          errorMessage: error instanceof Error ? error.message : "Unknown error",
          completedAt: new Date(),
        });
      }
      throw error;
    }
  }

  private async runSpiderFootCommand(target: string): Promise<any> {
    return new Promise((resolve, reject) => {
      // Check if SpiderFoot is available
      const checkCmd = spawn('python3', ['-c', 'import spiderfoot'], { stdio: 'pipe' });
      
      checkCmd.on('close', (code) => {
        if (code !== 0) {
          // SpiderFoot not available, return mock data
          console.warn("SpiderFoot not available, using mock data");
          resolve(this.getMockSpiderFootResults(target));
          return;
        }

        // Run actual SpiderFoot command
        // Note: This is a simplified version. Real SpiderFoot integration would require
        // setting up the web interface or using the API
        const tempDir = path.join(os.tmpdir(), 'spiderfoot-' + Date.now());
        const args = [
          '-m', 'spiderfoot',
          '-s', target,
          '-o', 'json',
          '-d', tempDir
        ];

        const child = spawn('python3', args, {
          stdio: ['pipe', 'pipe', 'pipe'],
          timeout: 600000, // 10 minutes timeout
        });

        let stdout = '';
        let stderr = '';

        child.stdout.on('data', (data) => {
          stdout += data.toString();
        });

        child.stderr.on('data', (data) => {
          stderr += data.toString();
        });

        child.on('close', (code) => {
          if (code === 0) {
            resolve(this.getMockSpiderFootResults(target));
          } else {
            console.error("SpiderFoot failed:", stderr);
            resolve(this.getMockSpiderFootResults(target));
          }
        });

        child.on('error', (error) => {
          console.error("SpiderFoot spawn error:", error);
          resolve(this.getMockSpiderFootResults(target));
        });
      });
    });
  }

  private getMockSpiderFootResults(target: string): any {
    // Mock SpiderFoot results
    return {
      target,
      results: [
        {
          type: "DNS_A",
          data: "93.184.216.34",
          source: "DNS",
          confidence: 100,
          timestamp: new Date().toISOString()
        },
        {
          type: "WHOIS",
          data: {
            registrar: "MarkMonitor Inc.",
            creation_date: "1995-08-14",
            expiration_date: "2025-08-13",
            nameservers: ["a.iana-servers.net", "b.iana-servers.net"]
          },
          source: "WHOIS",
          confidence: 100,
          timestamp: new Date().toISOString()
        },
        {
          type: "EMAIL_ADDRESS",
          data: "contact@example.com",
          source: "WEB_SCRAPING",
          confidence: 85,
          timestamp: new Date().toISOString()
        },
        {
          type: "PHONE_NUMBER",
          data: "+1-555-123-4567",
          source: "WEB_SCRAPING",
          confidence: 70,
          timestamp: new Date().toISOString()
        }
      ],
      summary: {
        total_findings: 4,
        dns_records: 1,
        whois_data: 1,
        email_addresses: 1,
        phone_numbers: 1,
        social_media: 0,
        threat_intel: 0
      }
    };
  }

  private async processResults(spiderfootResults: any, investigationId: string, resultId?: string): Promise<void> {
    const findings = [];
    
    for (const result of spiderfootResults.results) {
      let severity: "low" | "medium" | "high" | "critical" = "low";
      let description = "";

      switch (result.type) {
        case "DNS_A":
          description = `DNS A record found: ${result.data}`;
          severity = "low";
          break;
        case "WHOIS":
          description = `WHOIS data available for domain`;
          severity = "low";
          break;
        case "EMAIL_ADDRESS":
          description = `Email address found: ${result.data}`;
          severity = "medium";
          break;
        case "PHONE_NUMBER":
          description = `Phone number found: ${result.data}`;
          severity = "medium";
          break;
        default:
          description = `${result.type}: ${typeof result.data === 'string' ? result.data : JSON.stringify(result.data)}`;
      }

      findings.push({
        investigationId,
        resultId: resultId!,
        type: "technical_data",
        platform: "spiderfoot",
        description,
        severity,
        confidence: result.confidence || 50,
        metadata: {
          spiderfoot_type: result.type,
          source: result.source,
          data: result.data,
          timestamp: result.timestamp
        }
      });
    }

    // Store all findings
    for (const finding of findings) {
      await storage.createFinding(finding);
    }

    // Update result status
    if (resultId) {
      await storage.updateInvestigationResult(resultId, {
        status: "completed",
        results: spiderfootResults,
        completedAt: new Date(),
      });
    }
  }
}

export const spiderfootService = new SpiderFootService();
