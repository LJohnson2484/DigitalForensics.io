import { storage } from "../storage";

// Mock pyhibp functionality since it requires API keys
class HIBPService {
  async run(email: string, investigationId: string): Promise<void> {
    console.log(`Running HaveIBeenPwned for email: ${email}`);
    
    // Update result status to running
    const results = await storage.getInvestigationResults(investigationId);
    const hibpResult = results.find(r => r.toolName === 'hibp');
    if (hibpResult) {
      await storage.updateInvestigationResult(hibpResult.id, {
        status: "running",
        startedAt: new Date(),
      });
    }

    try {
      // In production, this would use the actual pyhibp library:
      // import pyhibp from 'pyhibp';
      // const breaches = await pyhibp.getBreachedAccount(email);
      
      // For now, use environment variable or mock data
      const apiKey = process.env.HIBP_API_KEY;
      let breaches;
      
      if (apiKey) {
        breaches = await this.checkRealHIBP(email, apiKey);
      } else {
        console.warn("HIBP_API_KEY not found, using mock data");
        breaches = this.getMockBreaches(email);
      }
      
      await this.processResults(breaches, investigationId, hibpResult?.id);
      
    } catch (error) {
      console.error("HIBP service error:", error);
      if (hibpResult) {
        await storage.updateInvestigationResult(hibpResult.id, {
          status: "failed",
          errorMessage: error instanceof Error ? error.message : "Unknown error",
          completedAt: new Date(),
        });
      }
      throw error;
    }
  }

  private async checkRealHIBP(email: string, apiKey: string): Promise<any[]> {
    try {
      const response = await fetch(`https://haveibeenpwned.com/api/v3/breachedaccount/${email}`, {
        headers: {
          'hibp-api-key': apiKey,
          'User-Agent': 'DigitalForensics.io/1.0.0'
        }
      });

      if (response.status === 404) {
        return []; // No breaches found
      }

      if (!response.ok) {
        throw new Error(`HIBP API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error("Real HIBP check failed:", error);
      return this.getMockBreaches(email);
    }
  }

  private getMockBreaches(email: string): any[] {
    // Mock breach data for demonstration
    return [
      {
        "Name": "Adobe",
        "Title": "Adobe",
        "Domain": "adobe.com",
        "BreachDate": "2013-10-04",
        "AddedDate": "2013-12-04T00:00:00Z",
        "ModifiedDate": "2013-12-04T00:00:00Z",
        "PwnCount": 152445165,
        "Description": "In October 2013, 153 million Adobe accounts were breached with each containing an internal ID, username, email, encrypted password and a password hint in plain text.",
        "DataClasses": ["Email addresses", "Password hints", "Passwords", "Usernames"],
        "IsVerified": true,
        "IsFabricated": false,
        "IsSensitive": false,
        "IsRetired": false,
        "IsSpamList": false
      },
      {
        "Name": "LinkedIn",
        "Title": "LinkedIn",
        "Domain": "linkedin.com",
        "BreachDate": "2012-05-05",
        "AddedDate": "2016-05-21T21:35:40Z",
        "ModifiedDate": "2016-05-21T21:35:40Z",
        "PwnCount": 164611595,
        "Description": "In May 2012, LinkedIn disclosed a data breach had occurred, but password security was insufficient.",
        "DataClasses": ["Email addresses", "Passwords"],
        "IsVerified": true,
        "IsFabricated": false,
        "IsSensitive": false,
        "IsRetired": false,
        "IsSpamList": false
      }
    ];
  }

  private async processResults(breaches: any[], investigationId: string, resultId?: string): Promise<void> {
    const findings = [];
    
    for (const breach of breaches) {
      findings.push({
        investigationId,
        resultId: resultId!,
        type: "breach",
        platform: breach.Name.toLowerCase(),
        url: `https://${breach.Domain}`,
        description: `Found in ${breach.Name} data breach (${breach.BreachDate})`,
        severity: this.calculateSeverity(breach),
        confidence: 95,
        metadata: {
          breachDate: breach.BreachDate,
          addedDate: breach.AddedDate,
          pwnCount: breach.PwnCount,
          dataClasses: breach.DataClasses,
          description: breach.Description,
          isVerified: breach.IsVerified,
          isSensitive: breach.IsSensitive
        }
      });
    }

    // Store all findings
    for (const finding of findings) {
      await storage.createFinding(finding);
    }

    // Update result status
    if (resultId) {
      await storage.updateInvestigationResult(resultId, {
        status: "completed",
        results: { breaches },
        completedAt: new Date(),
      });
    }
  }

  private calculateSeverity(breach: any): "low" | "medium" | "high" | "critical" {
    if (breach.IsSensitive) return "critical";
    if (breach.DataClasses.includes("Passwords")) return "high";
    if (breach.DataClasses.includes("Email addresses")) return "medium";
    return "low";
  }
}

export const hibpService = new HIBPService();
