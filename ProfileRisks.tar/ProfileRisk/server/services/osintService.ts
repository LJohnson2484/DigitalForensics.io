import { storage } from "../storage";
import { maigretService } from "./maigretService";
import { hibpService } from "./hibpService";
import { namechkService } from "./namechkService";
import { spiderfootService } from "./spiderfootService";
import { riskAssessment } from "./riskAssessment";

interface ToolService {
  run(target: string, investigationId: string): Promise<void>;
}

class OSINTService {
  private toolServices: Record<string, ToolService> = {
    maigret: maigretService,
    hibp: hibpService,
    namechk: namechkService,
    spiderfoot: spiderfootService,
  };

  async startInvestigation(investigationId: string): Promise<void> {
    try {
      const investigation = await storage.getInvestigation(investigationId);
      if (!investigation) {
        throw new Error(`Investigation ${investigationId} not found`);
      }

      // Update status to running
      await storage.updateInvestigation(investigationId, {
        status: "running",
        startedAt: new Date(),
        progress: 0,
      });

      const enabledTools = investigation.toolsEnabled as string[];
      const totalTools = enabledTools.length;

      // Create result entries for each tool
      for (const toolName of enabledTools) {
        await storage.createInvestigationResult({
          investigationId,
          toolName,
          status: "pending",
        });
      }

      // Run tools sequentially to avoid overwhelming the system
      let completedTools = 0;
      for (const toolName of enabledTools) {
        try {
          const toolService = this.toolServices[toolName];
          if (toolService) {
            console.log(`Starting ${toolName} for investigation ${investigationId}`);
            await toolService.run(investigation.targetValue, investigationId);
            completedTools++;
            
            // Update progress
            const progress = Math.round((completedTools / totalTools) * 100);
            await storage.updateInvestigation(investigationId, { progress });
          }
        } catch (error) {
          console.error(`Error running ${toolName} for investigation ${investigationId}:`, error);
          // Update the specific result with error
          const results = await storage.getInvestigationResults(investigationId);
          const result = results.find(r => r.toolName === toolName);
          if (result) {
            await storage.updateInvestigationResult(result.id, {
              status: "failed",
              errorMessage: error instanceof Error ? error.message : "Unknown error",
              completedAt: new Date(),
            });
          }
        }
      }

      // Calculate final risk assessment
      const findings = await storage.getInvestigationFindings(investigationId);
      const riskAssessmentResult = riskAssessment.calculateRisk(findings);

      // Update investigation as completed
      await storage.updateInvestigation(investigationId, {
        status: "completed",
        completedAt: new Date(),
        progress: 100,
        riskScore: riskAssessmentResult.score,
        riskLevel: riskAssessmentResult.level,
      });

      console.log(`Investigation ${investigationId} completed successfully`);
    } catch (error) {
      console.error(`Investigation ${investigationId} failed:`, error);
      await storage.updateInvestigation(investigationId, {
        status: "failed",
        completedAt: new Date(),
      });
    }
  }
}

export const osintService = new OSINTService();
