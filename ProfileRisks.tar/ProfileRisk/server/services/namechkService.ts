import { storage } from "../storage";
import { spawn } from "child_process";

class NamechkService {
  async run(username: string, investigationId: string): Promise<void> {
    console.log(`Running Namechk for username: ${username}`);
    
    // Update result status to running
    const results = await storage.getInvestigationResults(investigationId);
    const namechkResult = results.find(r => r.toolName === 'namechk');
    if (namechkResult) {
      await storage.updateInvestigationResult(namechkResult.id, {
        status: "running",
        startedAt: new Date(),
      });
    }

    try {
      // Check availability across multiple platforms
      const platformResults = await this.checkMultiplePlatforms(username);
      await this.processResults(platformResults, investigationId, namechkResult?.id);
      
    } catch (error) {
      console.error("Namechk service error:", error);
      if (namechkResult) {
        await storage.updateInvestigationResult(namechkResult.id, {
          status: "failed",
          errorMessage: error instanceof Error ? error.message : "Unknown error",
          completedAt: new Date(),
        });
      }
      throw error;
    }
  }

  private async checkMultiplePlatforms(username: string): Promise<any> {
    const platforms = [
      { name: 'Twitter', url: `https://twitter.com/${username}`, icon: 'fab fa-twitter' },
      { name: 'GitHub', url: `https://github.com/${username}`, icon: 'fab fa-github' },
      { name: 'Instagram', url: `https://instagram.com/${username}`, icon: 'fab fa-instagram' },
      { name: 'LinkedIn', url: `https://linkedin.com/in/${username}`, icon: 'fab fa-linkedin' },
      { name: 'Reddit', url: `https://reddit.com/u/${username}`, icon: 'fab fa-reddit' },
      { name: 'YouTube', url: `https://youtube.com/@${username}`, icon: 'fab fa-youtube' },
      { name: 'TikTok', url: `https://tiktok.com/@${username}`, icon: 'fab fa-tiktok' },
      { name: 'Facebook', url: `https://facebook.com/${username}`, icon: 'fab fa-facebook' },
    ];

    const results = { available: 0, taken: 0, unknown: 0, platforms: [] as any[] };

    for (const platform of platforms) {
      try {
        const availability = await this.checkSinglePlatform(platform.url);
        results.platforms.push({
          name: platform.name,
          url: platform.url,
          icon: platform.icon,
          status: availability,
        });

        if (availability === 'available') results.available++;
        else if (availability === 'taken') results.taken++;
        else results.unknown++;

        // Rate limiting to avoid being blocked
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`Error checking ${platform.name}:`, error);
        results.platforms.push({
          name: platform.name,
          url: platform.url,
          icon: platform.icon,
          status: 'unknown',
        });
        results.unknown++;
      }
    }

    return results;
  }

  private async checkSinglePlatform(url: string): Promise<'available' | 'taken' | 'unknown'> {
    try {
      const response = await fetch(url, {
        method: 'HEAD',
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
      });

      // 404 typically means username is available
      if (response.status === 404) return 'available';
      // 200 means username is taken
      if (response.status === 200) return 'taken';
      // Other status codes are unclear
      return 'unknown';
    } catch (error) {
      // Network errors or timeouts
      return 'unknown';
    }
  }

  private async processResults(platformResults: any, investigationId: string, resultId?: string): Promise<void> {
    const findings = [];
    
    for (const platform of platformResults.platforms) {
      if (platform.status === 'taken') {
        findings.push({
          investigationId,
          resultId: resultId!,
          type: "username_availability",
          platform: platform.name.toLowerCase(),
          url: platform.url,
          description: `Username taken on ${platform.name}`,
          severity: "low" as const,
          confidence: 80,
          metadata: {
            status: platform.status,
            icon: platform.icon
          }
        });
      }
    }

    // Store all findings
    for (const finding of findings) {
      await storage.createFinding(finding);
    }

    // Update result status
    if (resultId) {
      await storage.updateInvestigationResult(resultId, {
        status: "completed",
        results: platformResults,
        completedAt: new Date(),
      });
    }
  }
}

export const namechkService = new NamechkService();
