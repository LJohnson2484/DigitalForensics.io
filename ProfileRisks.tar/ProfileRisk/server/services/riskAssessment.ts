import { Finding } from "@shared/schema";

interface RiskAssessmentResult {
  score: number; // 0-100
  level: "low" | "medium" | "high" | "critical";
  factors: string[];
  recommendations: string[];
}

class RiskAssessment {
  calculateRisk(findings: Finding[]): RiskAssessmentResult {
    let totalScore = 0;
    const factors: string[] = [];
    const recommendations: string[] = [];

    // Base scoring
    const severityWeights = {
      low: 1,
      medium: 3,
      high: 7,
      critical: 10
    };

    // Count findings by type and severity
    const findingsByType = this.groupFindingsByType(findings);
    
    // Social media exposure scoring
    if (findingsByType.social_media?.length > 0) {
      const socialScore = Math.min(findingsByType.social_media.length * 2, 20);
      totalScore += socialScore;
      factors.push(`${findingsByType.social_media.length} social media accounts found`);
      
      if (findingsByType.social_media.length > 10) {
        recommendations.push("Consider reducing social media footprint");
      }
    }

    // Data breach scoring
    if (findingsByType.breach?.length > 0) {
      const breachScore = findingsByType.breach.length * 8;
      totalScore += breachScore;
      factors.push(`Found in ${findingsByType.breach.length} data breaches`);
      recommendations.push("Change passwords for compromised accounts");
      recommendations.push("Enable two-factor authentication where possible");
    }

    // Username availability (lower risk)
    if (findingsByType.username_availability?.length > 0) {
      const usernameScore = Math.min(findingsByType.username_availability.length * 1, 10);
      totalScore += usernameScore;
      factors.push(`Username taken on ${findingsByType.username_availability.length} platforms`);
    }

    // Technical data exposure
    if (findingsByType.technical_data?.length > 0) {
      const techScore = findingsByType.technical_data.length * 3;
      totalScore += techScore;
      factors.push(`${findingsByType.technical_data.length} technical data points found`);
    }

    // Apply severity multipliers
    for (const finding of findings) {
      const weight = severityWeights[finding.severity];
      totalScore += weight;
    }

    // High-risk indicators
    const hasPhoneNumbers = findings.some(f => f.description.toLowerCase().includes('phone'));
    const hasEmailAddresses = findings.some(f => f.description.toLowerCase().includes('email'));
    const hasPersonalInfo = findings.some(f => f.severity === 'critical');

    if (hasPhoneNumbers) {
      totalScore += 5;
      factors.push("Phone numbers exposed");
      recommendations.push("Consider phone number privacy settings");
    }

    if (hasEmailAddresses) {
      totalScore += 3;
      factors.push("Email addresses found");
    }

    if (hasPersonalInfo) {
      totalScore += 15;
      factors.push("Sensitive personal information exposed");
      recommendations.push("Review privacy settings on all accounts");
    }

    // Confidence-based adjustments
    const highConfidenceFindings = findings.filter(f => f.confidence >= 90);
    if (highConfidenceFindings.length > findings.length * 0.8) {
      totalScore *= 1.1; // 10% boost for high confidence
    }

    // Cap the score at 100
    const finalScore = Math.min(Math.round(totalScore), 100);

    // Determine risk level
    let level: "low" | "medium" | "high" | "critical";
    if (finalScore >= 80) level = "critical";
    else if (finalScore >= 60) level = "high";
    else if (finalScore >= 30) level = "medium";
    else level = "low";

    // Add general recommendations
    if (level === "critical" || level === "high") {
      recommendations.unshift("Immediate action required to reduce digital exposure");
    }
    
    if (factors.length === 0) {
      factors.push("No significant exposure detected");
      recommendations.push("Maintain current privacy practices");
    }

    return {
      score: finalScore,
      level,
      factors,
      recommendations
    };
  }

  private groupFindingsByType(findings: Finding[]): Record<string, Finding[]> {
    return findings.reduce((groups, finding) => {
      const type = finding.type;
      if (!groups[type]) {
        groups[type] = [];
      }
      groups[type].push(finding);
      return groups;
    }, {} as Record<string, Finding[]>);
  }
}

export const riskAssessment = new RiskAssessment();
