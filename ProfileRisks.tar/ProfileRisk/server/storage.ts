import {
  users,
  investigations,
  investigationResults,
  findings,
  type User,
  type UpsertUser,
  type Investigation,
  type InsertInvestigation,
  type InvestigationResult,
  type InsertInvestigationResult,
  type Finding,
  type InsertFinding,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Investigation operations
  createInvestigation(investigation: InsertInvestigation): Promise<Investigation>;
  getInvestigation(id: string): Promise<Investigation | undefined>;
  getUserInvestigations(userId: string): Promise<Investigation[]>;
  updateInvestigation(id: string, updates: Partial<Investigation>): Promise<Investigation>;
  
  // Investigation results operations
  createInvestigationResult(result: InsertInvestigationResult): Promise<InvestigationResult>;
  getInvestigationResults(investigationId: string): Promise<InvestigationResult[]>;
  updateInvestigationResult(id: string, updates: Partial<InvestigationResult>): Promise<InvestigationResult>;
  
  // Findings operations
  createFinding(finding: InsertFinding): Promise<Finding>;
  getInvestigationFindings(investigationId: string): Promise<Finding[]>;
  getFindingsByTool(investigationId: string, toolName: string): Promise<Finding[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Investigation operations
  async createInvestigation(investigation: InsertInvestigation): Promise<Investigation> {
    const [result] = await db
      .insert(investigations)
      .values(investigation)
      .returning();
    return result;
  }

  async getInvestigation(id: string): Promise<Investigation | undefined> {
    const [investigation] = await db
      .select()
      .from(investigations)
      .where(eq(investigations.id, id));
    return investigation;
  }

  async getUserInvestigations(userId: string): Promise<Investigation[]> {
    return await db
      .select()
      .from(investigations)
      .where(eq(investigations.userId, userId))
      .orderBy(desc(investigations.createdAt));
  }

  async updateInvestigation(id: string, updates: Partial<Investigation>): Promise<Investigation> {
    const [investigation] = await db
      .update(investigations)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(investigations.id, id))
      .returning();
    return investigation;
  }

  // Investigation results operations
  async createInvestigationResult(result: InsertInvestigationResult): Promise<InvestigationResult> {
    const [investigationResult] = await db
      .insert(investigationResults)
      .values(result)
      .returning();
    return investigationResult;
  }

  async getInvestigationResults(investigationId: string): Promise<InvestigationResult[]> {
    return await db
      .select()
      .from(investigationResults)
      .where(eq(investigationResults.investigationId, investigationId));
  }

  async updateInvestigationResult(id: string, updates: Partial<InvestigationResult>): Promise<InvestigationResult> {
    const [result] = await db
      .update(investigationResults)
      .set(updates)
      .where(eq(investigationResults.id, id))
      .returning();
    return result;
  }

  // Findings operations
  async createFinding(finding: InsertFinding): Promise<Finding> {
    const [result] = await db
      .insert(findings)
      .values(finding)
      .returning();
    return result;
  }

  async getInvestigationFindings(investigationId: string): Promise<Finding[]> {
    return await db
      .select()
      .from(findings)
      .where(eq(findings.investigationId, investigationId));
  }

  async getFindingsByTool(investigationId: string, toolName: string): Promise<Finding[]> {
    return await db
      .select()
      .from(findings)
      .where(
        and(
          eq(findings.investigationId, investigationId),
          eq(findings.type, toolName)
        )
      );
  }
}

export const storage = new DatabaseStorage();
