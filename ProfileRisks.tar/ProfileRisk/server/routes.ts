import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertInvestigationSchema, insertInvestigationResultSchema } from "@shared/schema";
import { osintService } from "./services/osintService";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Investigation routes
  app.post('/api/investigations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertInvestigationSchema.parse({
        ...req.body,
        userId,
        toolsEnabled: req.body.toolsEnabled || ['maigret', 'hibp', 'namechk']
      });

      const investigation = await storage.createInvestigation(data);
      
      // Start OSINT investigation asynchronously
      osintService.startInvestigation(investigation.id).catch(error => {
        console.error(`Investigation ${investigation.id} failed:`, error);
      });

      res.json(investigation);
    } catch (error) {
      console.error("Error creating investigation:", error);
      res.status(400).json({ message: "Invalid investigation data" });
    }
  });

  app.get('/api/investigations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investigations = await storage.getUserInvestigations(userId);
      res.json(investigations);
    } catch (error) {
      console.error("Error fetching investigations:", error);
      res.status(500).json({ message: "Failed to fetch investigations" });
    }
  });

  app.get('/api/investigations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const investigation = await storage.getInvestigation(req.params.id);
      if (!investigation) {
        return res.status(404).json({ message: "Investigation not found" });
      }

      // Check if user owns this investigation
      const userId = req.user.claims.sub;
      if (investigation.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(investigation);
    } catch (error) {
      console.error("Error fetching investigation:", error);
      res.status(500).json({ message: "Failed to fetch investigation" });
    }
  });

  app.get('/api/investigations/:id/results', isAuthenticated, async (req: any, res) => {
    try {
      const investigation = await storage.getInvestigation(req.params.id);
      if (!investigation) {
        return res.status(404).json({ message: "Investigation not found" });
      }

      // Check if user owns this investigation
      const userId = req.user.claims.sub;
      if (investigation.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const results = await storage.getInvestigationResults(req.params.id);
      res.json(results);
    } catch (error) {
      console.error("Error fetching investigation results:", error);
      res.status(500).json({ message: "Failed to fetch investigation results" });
    }
  });

  app.get('/api/investigations/:id/findings', isAuthenticated, async (req: any, res) => {
    try {
      const investigation = await storage.getInvestigation(req.params.id);
      if (!investigation) {
        return res.status(404).json({ message: "Investigation not found" });
      }

      // Check if user owns this investigation
      const userId = req.user.claims.sub;
      if (investigation.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const findings = await storage.getInvestigationFindings(req.params.id);
      res.json(findings);
    } catch (error) {
      console.error("Error fetching investigation findings:", error);
      res.status(500).json({ message: "Failed to fetch investigation findings" });
    }
  });

  app.get('/api/investigations/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const investigation = await storage.getInvestigation(req.params.id);
      if (!investigation) {
        return res.status(404).json({ message: "Investigation not found" });
      }

      // Check if user owns this investigation
      const userId = req.user.claims.sub;
      if (investigation.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const results = await storage.getInvestigationResults(req.params.id);
      const findings = await storage.getInvestigationFindings(req.params.id);

      res.json({
        investigation,
        results,
        findings,
        summary: {
          totalFindings: findings.length,
          highSeverityFindings: findings.filter(f => f.severity === 'high' || f.severity === 'critical').length,
          completedTools: results.filter(r => r.status === 'completed').length,
          totalTools: results.length
        }
      });
    } catch (error) {
      console.error("Error fetching investigation status:", error);
      res.status(500).json({ message: "Failed to fetch investigation status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
