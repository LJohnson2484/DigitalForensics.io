import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Investigation cases
export const investigations = pgTable("investigations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  targetType: varchar("target_type").notNull(), // username, email, phone, domain
  targetValue: varchar("target_value").notNull(),
  status: varchar("status").notNull().default("pending"), // pending, running, completed, failed
  riskScore: integer("risk_score"),
  riskLevel: varchar("risk_level"), // low, medium, high, critical
  toolsEnabled: jsonb("tools_enabled").notNull(), // array of enabled tools
  progress: integer("progress").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Investigation results
export const investigationResults = pgTable("investigation_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  investigationId: varchar("investigation_id").notNull().references(() => investigations.id, { onDelete: "cascade" }),
  toolName: varchar("tool_name").notNull(), // maigret, hibp, namechk, spiderfoot
  status: varchar("status").notNull().default("pending"), // pending, running, completed, failed
  results: jsonb("results"), // tool-specific results
  errorMessage: text("error_message"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// OSINT findings
export const findings = pgTable("findings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  investigationId: varchar("investigation_id").notNull().references(() => investigations.id, { onDelete: "cascade" }),
  resultId: varchar("result_id").notNull().references(() => investigationResults.id, { onDelete: "cascade" }),
  type: varchar("type").notNull(), // social_media, breach, domain, phone, etc.
  platform: varchar("platform"), // twitter, facebook, adobe, etc.
  url: text("url"),
  description: text("description"),
  severity: varchar("severity").notNull(), // low, medium, high, critical
  confidence: integer("confidence").notNull().default(100), // 0-100
  metadata: jsonb("metadata"), // additional platform-specific data
  createdAt: timestamp("created_at").defaultNow(),
});

// Export types and schemas
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type Investigation = typeof investigations.$inferSelect;
export type InsertInvestigation = typeof investigations.$inferInsert;
export const insertInvestigationSchema = createInsertSchema(investigations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InvestigationResult = typeof investigationResults.$inferSelect;
export type InsertInvestigationResult = typeof investigationResults.$inferInsert;
export const insertInvestigationResultSchema = createInsertSchema(investigationResults).omit({
  id: true,
  createdAt: true,
});

export type Finding = typeof findings.$inferSelect;
export type InsertFinding = typeof findings.$inferInsert;
export const insertFindingSchema = createInsertSchema(findings).omit({
  id: true,
  createdAt: true,
});
